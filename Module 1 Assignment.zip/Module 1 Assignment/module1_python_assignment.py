# -*- coding: utf-8 -*-
"""Module1_Python_Assignment

GEMINI SIM MATTHEW
"""

workers = []
highest_salary = 30000
try:
  for employee_id in range(1, 401):
    gender = "M" if employee_id % 2 == 0 else "F"
    employee_salary = highest_salary / employee_id
    employee_level = ""

    if employee_salary > 7500 and employee_salary < 30000 and gender == "F":
      employee_level = "A5-F"
    elif employee_salary > 10000 and employee_salary < 20000:
      employee_level = "A1"
    else:
      employee_level = "N/A"

    workers.append({"id": employee_id, "salary": employee_salary , "level": employee_level, "gender": gender})
except ZeroDivisionError:
  print("division error")
except Exception as e:
    print(f"Unexpected error: {e}")