workers <- list()
highest_salary <- 30000

tryCatch({
  
  for (employee_id in 1:400) {
    
    gender <- ifelse(employee_id %% 2 == 0, "M", "F")
    employee_salary <- highest_salary / employee_id
    employee_level <- ""
    
    if (employee_salary > 7500 && employee_salary < 30000 && gender == "F") {
      employee_level <- "A5-F"
    } else if (employee_salary > 10000 && employee_salary < 20000) {
      employee_level <- "A1"
    } else {
      employee_level <- "N/A"
    }
    
    workers[[employee_id]] <- list(
      id     = employee_id,
      salary = round(employee_salary, 2),
      level  = employee_level,
      gender = gender
    )
    
    cat("Worker", employee_id,
        "| Salary: $", round(employee_salary, 2),
        "| Level:", employee_level,
        "| Gender:", gender, "\n")
  }
  
  cat("\nDone! Total workers processed:", length(workers), "\n")
  
}, error = function(e) {
  cat("Error occurred:", e$message, "\n")
})

